# Retry matrix

Fill one row for every consequential operation.

| Operation | Known no effect evidence | Known effect evidence | Ambiguous evidence | Idempotency authority | Retry budget | Residue check |
|---|---|---|---|---|---:|---|
| create comment | provider rejects before ID | public exact read-back | timeout after request | provider key or public target ID | 0 after ambiguity | draft or duplicate comment |
| send email | provider rejects before message ID | Sent folder exact read-back | timeout after send | provider idempotency key | 0 after ambiguity | duplicate recipient delivery |
| transfer value | signed transaction absent | confirmed chain receipt | broadcast timeout | nonce and chain state | 0 from timeout alone | pending nonce or duplicate transfer |
| deploy site | build never submitted | public digest and source ID | provider job accepted, public stale | release ID | 1 only if provider guarantees | stale release or partial asset set |

## Required rule

Retries are new actions unless the executor or provider can prove the intended effect is idempotent.

## Crash points to test

- after envelope persistence,
- after provider send,
- after provider response,
- after local receipt persistence,
- after external read-back,
- before cursor advance.
