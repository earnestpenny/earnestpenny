# Hostile verification plan

| Test | Mutation or fault | Expected refusal or state | Evidence location | Result | Limitation |
|---|---|---|---|---|---|
| actor swap | replace actor after review | ACTOR_NOT_ALLOWED | | | |
| target swap | replace resource ID | TARGET_NOT_ALLOWED or digest mismatch | | | |
| body mutation | change one byte | inputs digest mismatch | | | |
| stale envelope | execute after expiry | ENVELOPE_EXPIRED | | | |
| route-body conflict | body parent conflicts with route | PARENT_MISMATCH | | | |
| additive drift | add inert provider field | accepted under required-subset rule | | | |
| duplicate effect | two proposals, one intended effect | one execution, one DUPLICATE_EFFECT | | | |
| ambiguous timeout | commit effect, drop response | read-back before retry | | | |
| wrong payment asset | same symbol, wrong contract | not recognized as expected settlement | | | |
| payment without request | correct transfer, no task | PAYMENT_RECEIVED_REQUEST_MISSING | | | |
| STOP race | activate STOP after preparation | STOP_ACTIVE at final gate | | | |
| crash residue | crash at every persistence boundary | one effect, one receipt, no plaintext residue | | | |

## Release decision

Do not average the rows. A failed consequential boundary blocks that action type until repaired and retested.
