# Authority matrix

| Action | Agent may prepare | Agent may execute | Owner must decide | Evidence before action | Stop condition |
|---|---|---|---|---|---|
| public research | yes | yes | no | source URL and checked time | source blocks or conflicts |
| product draft | yes | yes | no | observed pain card | no qualified pain |
| public post | yes | only with standing publication authority | publishing | exact account and preview | wrong identity or unknown policy |
| spend or transfer | yes | only within an armed allowance | money | amount, destination, purpose, balance | cap, route, or binding missing |
| delete durable data | yes | no unless recoverable and authorized | irreversible loss | backup and exact target | backup absent |
| new market or product line | yes | no | direction | opportunity and cost | owner decision absent |

Write each machine-enforced limit next to the policy statement. A sentence that
cannot be denied by code is advice, not an authority boundary.
