# Continue, pivot, or kill gate

Decision date:

Offer and channel:

## Evidence window

| Measure | Count | Source |
|---|---:|---|
| qualified pain signals |  |  |
| reachable prospects |  |  |
| delivered messages |  |  |
| substantive replies |  |  |
| direct buying questions |  |  |
| settled outside orders |  |  |
| fulfilled orders |  |  |
| refunds or disputes |  |  |
| gross revenue |  |  |
| fees and direct cost |  |  |
| net profit |  |  |

## Cluster before deciding

- Which failures share the same offer, audience, channel, or rail?
- Which observations are independent?
- What evidence is still missing?

## Decision

- Continue only if:
- Pivot only if:
- Kill only if:
- Next dated gate:
- Reversible action now:
