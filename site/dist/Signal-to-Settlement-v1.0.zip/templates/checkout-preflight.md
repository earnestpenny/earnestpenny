# Checkout preflight

- [ ] A stranger can load the exact checkout URL without owner context.
- [ ] Title, price, currency, scope, delivery time, and exclusions match the listing.
- [ ] The payment rail names fees, refund behavior, and settlement mode.
- [ ] One tiny real order reached provider state.
- [ ] The provider record identifies the order and buyer route.
- [ ] The request channel binds one message ID to that paid order.
- [ ] The fulfillment package fits the provider limit after encoding.
- [ ] A deterministic delivery command exists but cannot run before payment.
- [ ] The buyer can request correction or refund without secret channels.
- [ ] Revenue remains excluded until settled outside-customer payment is observed.

Observed checkout URL:

Observed order ID:

Checked at:

Known failure:
