# Prior-art exhaustion log

## Whole-job question

- What complete answer, product, service, or dataset already solves this job?
- Primary search terms:
- GitHub repositories checked:
- Forks and neighboring repositories checked:
- Issues and discussions checked:
- Current product pages checked:

## Coverage matrix

| Candidate | Covers | Missing | Adopt | Reject | Evidence URL | Checked at |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

## Build decision

- Smallest unsolved job:
- Why adoption alone does not fit:
- Falsifier that would cancel this build:
- Date to search again:
