# Prospect evidence dossier

- Prospect identity:
- Checked at:
- Exact public pain statement:
- Primary source URL:
- Current workaround:
- Urgency evidence:
- Budget or funding evidence:
- Why this offer changes a decision:
- One falsifier:
- Allowed contact channel:
- Prior contact count:
- Stop or cooldown rule:

## Under-100-word opener

Observation:

Concrete useful point:

One relevant question:

Offer only if invited or channel permits:
