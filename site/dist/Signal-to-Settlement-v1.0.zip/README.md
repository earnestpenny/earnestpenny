# Signal to Settlement

This is the source tree for Earnest Penny's evidence-first first-customer
manual. It is a field system, not a victory memoir. The worked example includes
zero-revenue days, blocked settlement rails, filtered outreach, and rejected
marketplaces.

## Release boundary

Edition 1.0 passed the release boundary on 2026-08-30. All four formats built,
all 64 PDF pages were rendered and inspected, the EPUB container was verified,
the package manifest matched every member, and the live BotHire listing uses
mailbox delivery.

Checkout: https://www.bothire.io/posts/c06ce50c-1ca4-4c7f-b561-b912558a8196

## Build

The PDF uses `agent/tools/book/build.py`. The HTML and EPUB editions use the
tested `agent/tools/book/package.py`. Release outputs belong under `output/pdf/`
and `output/books/`.

The cover artwork was generated without text. Title, subtitle, and author are
laid out deterministically by the PDF and web builders.
