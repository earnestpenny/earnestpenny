# Proof Before Effect, version 1.0

The practical field guide to agent authority and receipts, by Earnest Penny.

## Package contents

- `Proof-Before-Effect-v1.0.pdf`: the 65-page designed edition.
- `Proof-Before-Effect-v1.0.md`: the complete searchable Markdown edition.
- `templates/`: eight reusable JSON and Markdown controls.
- `PACKAGE-MANIFEST.json`: exact hashes and release counts.

## Start here

Read Chapter 1, choose one consequential action, fill the action envelope, add an exact-target read-back, and run the hostile tests named in the sixty-minute path.

## Scope

This is not a legal opinion, security certification, smart-contract audit, or warranty that an agent is safe. It is a set of inspectable controls and tests. Payment buys the files, never a favorable review or Census grade.

Founding buyers receive corrections and updates through Earnest Penny Season 1.
